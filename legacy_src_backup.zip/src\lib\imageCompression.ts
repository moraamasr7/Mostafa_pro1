// دالة ضغط الصور على المتصفح باستخدام Canvas لتقليل حجم الصورة بسرعة وكفاءة قبل رفعها لـ Supabase
export async function compressImage(
  file: File,
  maxWidth = 1200,
  maxHeight = 1200,
  quality = 0.75
): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()

    reader.onload = (event) => {
      const img = new Image()

      img.onload = () => {
        let width = img.width
        let height = img.height

        // المحافظة على التناسب (Aspect Ratio) عند ضبط الأبعاد القصوى
        if (width > maxWidth || height > maxHeight) {
          if (width > height) {
            height = Math.round((height * maxWidth) / width)
            width = maxWidth
          } else {
            width = Math.round((width * maxHeight) / height)
            height = maxHeight
          }
        }

        const canvas = document.createElement('canvas')
        canvas.width = width
        canvas.height = height

        const ctx = canvas.getContext('2d')
        if (!ctx) {
          reject(new Error('تعذر إنشاء سياق Canvas لضغط الصورة'))
          return
        }

        ctx.drawImage(img, 0, 0, width, height)

        canvas.toBlob(
          (blob) => {
            if (blob) {
              resolve(blob)
            } else {
              reject(new Error('فشل عملية ضغط الصورة'))
            }
          },
          'image/jpeg',
          quality
        )
      }

      img.onerror = () => reject(new Error('تعذر تحميل الصورة لضغطها'))
      img.src = event.target?.result as string
    }

    reader.onerror = () => reject(new Error('تعذر قراءة ملف الصورة'))
    reader.readAsDataURL(file)
  })
}
